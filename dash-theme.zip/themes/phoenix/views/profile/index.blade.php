@extends('layouts.main')

@php
  $general_settings = app(App\Settings\GeneralSettings::class);
@endphp

@section('content')

  <x-container title="Profile">
    <div class="ease-soft-in-out xl:ml-68.5 relative text-gray-700 transition-all duration-200 dark:text-gray-200">

      @if (!Auth::user()->hasVerifiedEmail() && $force_email_verification)
        <x-alert type="danger" title="Required Email verification!">
          <p>
            {{ __('You have not yet verified your email address') }} <br>
            <a class="text-primary underline"
              href="{{ route('verification.send') }}">{{ __('Click here to resend verification email') }}</a>
            <br>
            {{ __('Please contact support If you didnt receive your verification email.') }}
          </p>
        </x-alert>
      @endif

      @if (is_null(Auth::user()->discordUser) && $force_discord_verification)
        @if (!empty($discord_client_id) && !empty($discord_client_secret))
          <x-alert type="danger" title="Required Discord verification">
            <p>
              {{ __('You have not yet verified your discord account') }} <br>
              <a class="text-primary underline" href="{{ route('auth.redirect') }}">{{ __('Login with discord') }}</a>
              <br>
              {{ __('Please contact support If you face any issues.') }}
            </p>
          </x-alert>
        @else
          <x-alert type="danger" title="Required Discord verification">
            <p>
              {{ __('Due to system settings you are required to verify your discord account!') }} <br>
              {{ __('It looks like this hasnt been set-up correctly! Please contact support.') }}
            </p>
          </x-alert>
        @endif
      @endif

      <div class="mx-auto w-full">
        <div class="min-h-75 relative mt-6 flex items-center overflow-hidden rounded-2xl bg-cover bg-center p-0"
          style="background-image: url('{{ asset('images/user_profile_bg.webp') }}'); background-position-y: 50%; height: 200px;">
          <span
            class="absolute inset-y-0 h-full w-full bg-gradient-to-tl from-primary-700 to-pink-500 bg-cover bg-center opacity-60"></span>
        </div>
        <div
          class="shadow-blur relative mx-6 -mt-16 flex min-w-0 flex-auto flex-col overflow-hidden break-words rounded-2xl border-0 bg-white/80 bg-clip-border p-4 backdrop-blur-2xl backdrop-saturate-200 dark:bg-gray-800/80">
          <div class="-mx-3 flex flex-wrap">
            <div class="w-auto max-w-full flex-none px-3">
              <div
                class="ease-soft-in-out h-18.5 w-18.5 relative inline-flex items-center justify-center rounded-xl text-base text-white transition-all duration-200">
                <img src="{{ $user->getAvatar() }}" alt="profile_image" class="shadow-soft-sm w-full rounded-xl">
              </div>
            </div>
            <div class="my-auto w-auto max-w-full flex-none px-3">
              <div class="h-full">
                <h5 class="mb-1">{{ $user->name }}</h5>
                <p class="mb-0 text-sm font-semibold leading-normal">{{ $user->email }}</p>
              </div>
            </div>
            <div class="mx-auto mt-4 w-full max-w-full px-3 sm:my-auto sm:mr-0 md:w-1/2 md:flex-none lg:w-4/12">
              <div class="relative right-0">
                <ul class="on-resize relative flex list-none flex-col flex-wrap rounded-xl bg-transparent p-1"
                  nav-pills="" role="tablist">
                  <li class="z-30 flex-auto text-center">
                    <span
                      class="ease-soft-in-out z-30 mb-0 block w-full rounded-lg border-0 bg-inherit px-0 py-1 text-gray-700 transition-all dark:text-gray-200">
                      {{ Currency::formatForDisplay($user->credits) }} {{ $general_settings->credits_display_name }}
                    </span>
                  </li>
                  <li class="z-30 flex-auto text-center">

                    <small>{{ $user->created_at->isoFormat('LL') }}</small>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mx-auto w-full py-6">
        <div class="mb-8 grid gap-6 md:grid-cols-2">
          <div
            class="shadow-soft-xl relative flex h-full min-w-0 flex-col break-words rounded-2xl border-0 bg-white bg-clip-border dark:bg-gray-800">
            <div class="mb-0 rounded-t-2xl border-b-0 bg-white p-4 pb-0 dark:bg-gray-800">
              <div class="-mx-3 flex flex-wrap">
                <div class="flex w-full max-w-full shrink-0 items-center px-3 md:w-8/12 md:flex-none">
                  <h2 class="font-bold">{{ __('Profile Information') }}</h2>

                </div>
              </div>
            </div>
            <div class="p-4 pb-0">
              <ul class="mb-0 flex flex-col rounded-lg pl-0">
                <li
                  class="relative block rounded-t-lg border-0 bg-white px-4 py-2 pl-0 pt-0 text-sm leading-normal text-inherit dark:bg-gray-800">
                  <strong class="text-gray-700 dark:text-gray-200">User Name:</strong> &nbsp;
                  {{ $user->name }}
                </li>
                <li
                  class="relative block border-0 border-t-0 bg-white px-4 py-2 pl-0 text-sm leading-normal text-inherit dark:bg-gray-800">
                  <strong class="text-gray-700 dark:text-gray-200">Email:</strong> &nbsp;
                  {{ $user->email }}
                </li>
                @if ($referral_enabled)
                  <li data-content="Click to Copy" data-toggle="popover" data-trigger="hover" data-placement="top"
                    onclick="onClickCopy('{{ route('register') }}?ref={{ $user->referral_code }}')"
                    class="relative block cursor-copy border-0 border-t-0 bg-white px-4 py-2 pl-0 text-sm leading-normal text-gray-700 text-inherit hover:text-gray-600 dark:bg-gray-800 dark:text-gray-200 hover:dark:text-gray-400">
                    @can('user.referral')
                      <strong class="">Referral URL:</strong> &nbsp;
                      {{ route('register') }}?ref={{ $user->referral_code }}
                    @else
                      <span class="badge-warning rounded-full px-2 py-1 text-xs font-semibold leading-tight">
                        {{ _('You can not see your Referral Code') }}</span>
                    @endcan
                  </li>
                @endif
                <li
                  class="relative block border-0 border-t-0 bg-white px-4 py-2 pl-0 text-sm leading-normal text-inherit dark:bg-gray-800">
                  <strong class="text-gray-700 dark:text-gray-200">Role:</strong> &nbsp;

                  @foreach ($user->roles as $role)
                    <span class="rounded-full px-2 py-1 text-xs font-semibold leading-tight"
                      style='color: {{ $role->color }}; background-color: {{ $role->color }}2e;'>{{ $role->name }}</span>
                  @endforeach
                </li>
                <li
                  class="relative block rounded-t-lg border-0 bg-white px-4 py-2 pl-0 pt-0 text-sm leading-normal text-inherit dark:bg-gray-800">
                  <strong class="text-gray-700 dark:text-gray-200">Created At:</strong> &nbsp;
                  {{ $user->created_at->isoFormat('LL') }}
                </li>
              </ul>
            </div>

            <x-button class="m-4 mt-2 bg-red-500 text-white hover:bg-red-600 sm:w-1/3" id="confirmDeleteButton"
              type="button">{{ __('Delete Account') }}</x-button>
            @if (!empty($discord_client_id) && !empty($discord_client_secret))
              <div class="mt-4 p-4 pt-0">
                @if (is_null(Auth::user()->discordUser))
                  <b>{{ __('Link your discord account!') }}</b>
                  <div class="verify-discord">
                    <div class="mb-3">
                      @if ($credits_reward_after_verify_discord)
                        <p>
                          {{ __('By verifying your discord account, you receive extra Credits and increased Server amounts') }}
                        </p>
                      @endif
                    </div>
                  </div>

                  <a class="text-primary-600 underline" href="{{ route('auth.redirect') }}">
                    {{ __('Login with Discord') }}
                  </a>
                @else
                  <div class="verified-discord">
                    <div class="callout callout-info my-3">
                      <p>{{ __('You are verified!') }}</p>
                    </div>
                  </div>
                  <div class="flex items-center space-x-4 rounded-lg bg-gray-100 p-4 dark:bg-gray-700">
                    <img class="h-10 w-10 rounded-full" src="{{ $user->discordUser->getAvatar() }}"
                      alt="{{ $user->discordUser->username }}'s Avatar">
                    <div class="font-medium dark:text-white">
                      <div>{{ $user->discordUser->username }}</div>
                      <div class="text-sm text-gray-500 dark:text-gray-400">
                        {{ $user->discordUser->id }} <a href="{{ route('auth.redirect') }}"
                          class="text-primary-600 underline">{{ __('Re-Sync Discord') }}
                        </a></div>
                    </div>
                  </div>
                @endif

              </div>
            @endif
          </div>
          <div
            class="shadow-soft-xl relative flex h-full min-w-0 flex-col break-words rounded-2xl border-0 bg-white bg-clip-border dark:bg-gray-800">
            <div class="mb-0 rounded-t-2xl border-b-0 bg-white p-4 pb-0 dark:bg-gray-800">
              <h2 class="font-bold">{{ __('Settings') }}</h2>
            </div>
            <div class="flex-auto p-4">
              <form class="form" action="{{ route('profile.update', Auth::user()->id) }}" method="post">
                @csrf
                @method('PATCH')
                <div class="card">
                  <div class="card-body">
                    <div class="e-profile">

                      <div class="tab-content">

                        <!-- Validation Errors -->
                        <x-validation-errors class="mb-4" :errors="$errors" />

                        <label class="mb-3 block text-sm">
                          <span class="text-gray-700 dark:text-gray-400">{{ __('Name') }}</span>
                          <input x-todo="name" id="name" name="name" type="text"
                            class="focus:shadow-outline-purple dark:focus:shadow-outline-gray @error('name') border-red-300 focus:ring-red-200 @enderror mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-primary-400 focus:outline-none focus:ring focus:ring-primary-200 focus:ring-opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                            value="{{ $user->name }}" placeholder="{{ $user->name }}">
                        </label>

                        <label class="mb-3 block text-sm">
                          <span class="text-gray-700 dark:text-gray-400">{{ __('Email') }}</span>
                          <input x-todo="email" id="email" name="email" type="text"
                            class="focus:shadow-outline-purple dark:focus:shadow-outline-gray @error('email') border-red-300 focus:ring-red-200 @enderror mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-primary-400 focus:outline-none focus:ring focus:ring-primary-200 focus:ring-opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                            value="{{ $user->email }}" placeholder="{{ $user->email }}">
                        </label>

                        <div class="row">
                          <div class="col-12 col-sm-6 mb-3">
                            <h2 class="mb-3">{{ __('Change Password') }}</h2>
                            <div class="row">
                              <div class="col">
                                <div class="form-group">
                                  <label class="mb-3 block text-sm">
                                    <span class="text-gray-700 dark:text-gray-400">{{ __('Current Password') }}</span>
                                    <input x-todo="current_password" id="current_password" name="current_password"
                                      type="text"
                                      class="focus:shadow-outline-purple dark:focus:shadow-outline-gray @error('current_password') border-red-300 focus:ring-red-200 @enderror mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-primary-400 focus:outline-none focus:ring focus:ring-primary-200 focus:ring-opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                                      placeholder="••••••">
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <div class="form-group">
                                  <label class="mb-3 block text-sm">
                                    <span class="text-gray-700 dark:text-gray-400">{{ __('New Password') }}</span>
                                    <input x-todo="new_password" id="new_password" name="new_password" type="text"
                                      class="focus:shadow-outline-purple dark:focus:shadow-outline-gray @error('new_password') border-red-300 focus:ring-red-200 @enderror mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-primary-400 focus:outline-none focus:ring focus:ring-primary-200 focus:ring-opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                                      placeholder="••••••">
                                  </label>

                                </div>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <div class="form-group">

                                  <label class="mb-3 block text-sm">
                                    <span class="text-gray-700 dark:text-gray-400">{{ __('Confirm Password') }}</span>
                                    <input x-todo="new_password_confirmation" id="new_password_confirmation"
                                      name="new_password_confirmation" type="text"
                                      class="focus:shadow-outline-purple dark:focus:shadow-outline-gray @error('new_password_confirmation') border-red-300 focus:ring-red-200 @enderror mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-primary-400 focus:outline-none focus:ring focus:ring-primary-200 focus:ring-opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300"
                                      placeholder="••••••">
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col d-flex justify-content-end">

                            <button
                              class="focus:shadow-outline-purple rounded-lg border border-transparent bg-primary-600 px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 hover:bg-primary-700 focus:outline-none active:bg-primary-600"
                              type="submit">{{ __('Save Changes') }}</button>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </x-container>

  <script>
    document.getElementById("confirmDeleteButton").onclick = async () => {
      const {
        value: enterConfirm
      } = await Swal.fire({
        background: '#343a40',
        input: 'text',
        inputLabel: '{{ __('Are you sure you want to permanently delete your account and all of your servers?') }} \n Type "{{ __('Delete my account') }}" in the Box below',
        inputPlaceholder: "{{ __('Delete my account') }}",
        showCancelButton: true
      })
      if (enterConfirm === "{{ __('Delete my account') }}") {
        Swal.fire("{{ __('Account has been destroyed') }}", '', 'error')
        $.ajax({
          type: "POST",
          url: "{{ route('profile.selfDestroyUser') }}",
          data: `{
                    "confirmed": "yes",
                    }`,
          success: function(result) {
            console.log(result);
          },
          dataType: "json"
        });
        location.reload();

      } else {
        Swal.fire("{{ __('Account was NOT deleted.') }}", '', 'info')

      }

    }

    function onClickCopy(textToCopy) {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          Swal.fire({
            icon: 'success',
            title: '{{ __('URL copied to clipboard') }}',
            position: 'bottom-right',
            showConfirmButton: false,
            background: '#343a40',
            toast: true,
            timer: 1000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
        })
      } else {
        console.log('Browser Not compatible')
      }
    }
  </script>
@endsection
