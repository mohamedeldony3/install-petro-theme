<div class="flex items-center text-sm">
  {{ $slot }}
</div>
