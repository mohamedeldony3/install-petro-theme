@extends('layouts.main')
@section('head')
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.24/datatables.min.css" />
@endsection

@section('scripts')
  <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.24/datatables.min.js"></script>
@endsection
@section('content')
  <div class="container mx-auto grid">
    <div class="ease-soft-in-out xl:ml-68.5 relative text-gray-700 transition-all duration-200 dark:text-gray-200">

      <div class="mx-auto w-full px-6">
        <div class="min-h-75 relative mt-6 flex items-center overflow-hidden rounded-2xl bg-cover bg-center p-0"
          style="background-image: url('{{ asset('images/user_profile_bg.webp') }}'); background-position-y: 50%; height: 200px;">
          <span
            class="absolute inset-y-0 h-full w-full bg-gradient-to-tl from-primary-700 to-pink-500 bg-cover bg-center opacity-60"></span>
        </div>
        <div
          class="shadow-blur relative mx-6 -mt-16 flex min-w-0 flex-auto flex-col overflow-hidden break-words rounded-2xl border-0 bg-white/80 bg-clip-border p-4 backdrop-blur-2xl backdrop-saturate-200 dark:bg-gray-800/80">
          <div class="-mx-3 flex flex-wrap">
            <div class="w-auto max-w-full flex-none px-3">
              <div
                class="ease-soft-in-out h-18.5 w-18.5 relative inline-flex items-center justify-center rounded-xl text-base text-white transition-all duration-200">
                <img src="{{ $user->getAvatar() }}" alt="profile_image" class="shadow-soft-sm w-full rounded-xl">
              </div>
            </div>
            <div class="my-auto w-auto max-w-full flex-none px-3">
              <div class="h-full">
                <h5 class="mb-1">{{ $user->name }}</h5>
                <p class="mb-0 text-sm font-semibold leading-normal">{{ $user->email }}
                  @foreach ($user->roles as $role)
                    <span class="rounded-full px-2 py-1 text-xs font-semibold leading-tight"
                      style='color: {{ $role->color }}; background-color: {{ $role->color }}2e;'>{{ $role->name }}</span>
                  @endforeach
                </p>
                @if ($user->referredBy())
                  <p>{{ __('Referred by') }}: <a class="text-primary-500 underline"
                      href="{{ route('admin.users.show', $user->referredBy()->id) }}">{{ $user->referredBy()->name }}</a>
                  </p>
                @endif
              </div>
            </div>
            <div class="mx-auto mt-4 w-full max-w-full px-3 sm:my-auto sm:mr-0 md:w-1/2 md:flex-none lg:w-4/12">
              <div class="relative right-0">
                <ul class="on-resize relative flex list-none flex-col flex-wrap rounded-xl bg-transparent p-1"
                  nav-pills="" role="tablist">
                  <li class="z-30 flex-auto text-center">
                    <span
                      class="ease-soft-in-out z-30 mb-0 block w-full rounded-lg border-0 bg-inherit px-0 py-1 text-gray-700 transition-all dark:text-gray-200">
                      {{ Currency::formatForDisplay($user->credits) }} {{ $credits_display_name }}
                    </span>
                  </li>
                  <li class="z-30 flex-auto text-center">

                    <small>{{ $user->created_at->isoFormat('LL') }}</small>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mx-auto w-full p-6">
        <div class="grid gap-6">
          <div
            class="shadow-soft-xl relative flex h-full min-w-0 flex-col break-words rounded-2xl border-0 bg-white bg-clip-border dark:bg-gray-800">
            <div class="mb-0 rounded-t-2xl border-b-0 bg-white p-4 pb-0 dark:bg-gray-800">
              <div class="-mx-3 flex flex-wrap">
                <div class="flex w-full max-w-full shrink-0 items-center px-3 md:w-8/12 md:flex-none">
                  <h2 class="font-bold">{{ __('Profile Information') }}</h2>

                </div>
              </div>
              <div class="mb-8 mt-2 grid gap-6 md:grid-cols-2">
                <div class="w-full overflow-x-auto rounded-lg shadow-sm">
                  <table class="whitespace-no-wrap w-full">
                    <tbody class="divide-y bg-white dark:divide-gray-700 dark:bg-gray-800">
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('ID') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->id }}
                        </td>
                      </tr>

                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Pterodactyl ID') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->pterodactyl_id }}
                        </td>
                      </tr>
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Email') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->email }}
                        </td>
                      </tr>
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ $credits_display_name }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ Currency::formatForDisplay($user->credits) }}
                        </td>
                      </tr>

                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ $credits_display_name }} {{ __('Usage') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->CreditUsage() }} / {{ __('per month') }}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="w-full overflow-x-auto rounded-lg shadow-sm">
                  <table class="whitespace-no-wrap w-full">
                    <tbody class="divide-y bg-white dark:divide-gray-700 dark:bg-gray-800">
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Server Limit') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->Servers()->count() }} / {{ $user->server_limit }}
                        </td>
                      </tr>
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Verified') }} {{ __('Email') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->email_verified_at ? 'Yes' : 'No' }}
                        </td>
                      </tr>
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Verified') }} {{ __('Discord') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->discordUser ? 'Yes' : 'No' }}
                        </td>
                      </tr>
                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('IP') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          {{ $user->ip }}
                        </td>
                      </tr>

                      <tr class="text-gray-700 dark:text-gray-300">
                        <td class="px-4 py-3">
                          <div class="flex items-center text-sm">
                            <p class="font-semibold">
                              {{ __('Last Seen') }}
                            </p>
                          </div>
                        </td>

                        <td class="px-4 py-3 text-sm">
                          @if ($user->last_seen)
                            <x-tooltip :content="$user->last_seen->isoFormat('LLL')" pos="top" class="">
                              {{ $user->last_seen->diffForHumans() }}
                            </x-tooltip>
                          @else
                            <small class="text-muted">Null</small>
                          @endif
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            @if ($user->discordUser)
              <div class="p-4 pt-0">
                <div class="-mx-3 mb-2 flex flex-wrap">
                  <div class="flex w-full max-w-full shrink-0 items-center px-3 md:w-8/12 md:flex-none">
                    <h2 class="font-bold">{{ __('Discord Information') }}</h2>

                  </div>
                </div>
                <div class="flex items-center space-x-4 rounded-lg bg-gray-100 p-4 dark:bg-gray-700">
                  <img class="h-10 w-10 rounded-full" src="{{ $user->discordUser->getAvatar() }}"
                    alt="{{ $user->discordUser->username }}'s Avatar">
                  <div class="font-medium dark:text-white">
                    <div>{{ $user->discordUser->username }}</div>
                    <div class="text-sm text-gray-500 dark:text-gray-400">
                      {{ $user->discordUser->id }}
                    </div>
                  </div>
                </div>

              </div>
            @endif
          </div>

        </div>
      </div>
    </div>
  </div>

  <x-container title="Referrals (Code: {{ $user->referral_code }})">
    <div class="w-full overflow-x-auto rounded-lg shadow-sm">
      <table class="whitespace-no-wrap w-full">
        <thead>
          <tr
            class="border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-400">
            <td class="px-4 py-3">{{ __('User ID') }}</td>
            <td class="px-4 py-3">{{ __('User') }}</td>
            <td class="px-4 py-3">{{ __('Created At') }}</td>
          </tr>
        </thead>
        <tbody class="divide-y bg-white dark:divide-gray-700 dark:bg-gray-800">
          @forelse ($referrals as $referral)
            <tr class="text-gray-700 dark:text-gray-300">
              <td class="px-4 py-3">
                <div class="flex items-center text-sm">
                  <p class="font-semibold">
                    {{ $referral->id }}
                  </p>
                </div>
              </td>

              <td class="px-4 py-3 text-sm">
                <a href="{{ route('admin.users.show', $referral->id) }}"
                  class="text-primary-600 underline">{{ $referral->name }}</a>
              </td>
              <td class="px-4 py-3 text-sm">
                <x-tooltip :content="$referral->created_at->isoFormat('LLL')" pos="top" class="">
                  {{ $referral->created_at->diffForHumans() }}
                </x-tooltip>
              </td>
            </tr>
          @empty
            <tr class="text-gray-700 dark:text-gray-300">
              <td class="px-4 py-3" colspan="3">
                <div class="flex items-center text-sm">
                  No Referrals Found
                </div>
              </td>
            </tr>
          @endforelse

        </tbody>
      </table>
    </div>
  </x-container>
  <div class="container mx-auto grid px-6">

    <div class="flex justify-between py-6">

      <h2 class="text-xl font-semibold text-gray-700 dark:text-gray-200">
        {{ __('Servers') }}
      </h2>
    </div>
    @include('admin.servers.table', ['filter' => '?user=' . $user->id])
  </div>

  <script>
    function onClickCopy() {
      let textToCopy = document.getElementById('RefLink').innerText;
      if (navigator.clipboard) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          Swal.fire({
            icon: 'success',
            title: '{{ __('URL copied to clipboard') }}',
            position: 'top-middle',
            showConfirmButton: false,
            background: '#343a40',
            toast: false,
            timer: 1000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
          })
        })
      } else {
        console.log('Browser Not compatible')
      }
    }
  </script>
@endsection
