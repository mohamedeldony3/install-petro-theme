import Pace from 'pace-js';
import '../css/pace.css'
Pace.start();
window.Pace = Pace;
